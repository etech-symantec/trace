﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
title ProxySG Trace Launcher - Uninstall

echo Removing proxysg-trace:// registration for the current user...
reg delete "HKCU\Software\Classes\proxysg-trace" /f >nul 2>&1

set "APPDIR=%LOCALAPPDATA%\Etech\ProxySGTrace"
if exist "%APPDIR%\ProxySG_Trace_Launcher.cmd" del /q "%APPDIR%\ProxySG_Trace_Launcher.cmd" >nul 2>&1

echo.
echo [OK] Launcher protocol registration was removed.
echo Policy Trace Editor files were not deleted.
echo.
pause
