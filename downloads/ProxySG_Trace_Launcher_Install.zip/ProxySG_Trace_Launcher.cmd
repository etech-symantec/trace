﻿@echo off
setlocal EnableExtensions DisableDelayedExpansion
title ProxySG Trace Launcher

rem ============================================================
rem ProxySG Trace Launcher - one-shot launcher
rem - No network access
rem - No localhost listener
rem - No background/resident process
rem - No automatic download or update
rem ============================================================

set "APPDIR=%LOCALAPPDATA%\Etech\ProxySGTrace"
set "EDITOR="

rem 1) Preferred fixed location
if exist "%APPDIR%\ProxySG_Policy_Trace_Editor.exe" (
  set "EDITOR=%APPDIR%\ProxySG_Policy_Trace_Editor.exe"
  goto :run_editor
)

rem 2) Same folder as this launcher
if exist "%~dp0ProxySG_Policy_Trace_Editor.exe" (
  set "EDITOR=%~dp0ProxySG_Policy_Trace_Editor.exe"
  goto :run_editor
)

rem 3) Most recently downloaded Editor
for /f "delims=" %%F in ('dir /b /a-d /o-d "%USERPROFILE%\Downloads\ProxySG_Policy_Trace_Editor*.exe" 2^>nul') do (
  set "EDITOR=%USERPROFILE%\Downloads\%%F"
  goto :run_editor
)

rem 4) Desktop fallback
for /f "delims=" %%F in ('dir /b /a-d /o-d "%USERPROFILE%\Desktop\ProxySG_Policy_Trace_Editor*.exe" 2^>nul') do (
  set "EDITOR=%USERPROFILE%\Desktop\%%F"
  goto :run_editor
)

:not_found
echo.
echo ============================================================
echo   ProxySG Policy Trace Editor was not found.
echo ============================================================
echo.
echo The launcher does not download or install programs by itself.
echo Download the Editor from the official internal page first:
echo.
echo   https://etech-symantec.github.io/trace/?mode=direct
echo.
echo The launcher searches:
echo   1. %%LOCALAPPDATA%%\Etech\ProxySGTrace
echo   2. Launcher folder
echo   3. Downloads
echo   4. Desktop
echo.
start "" "https://etech-symantec.github.io/trace/?mode=direct"
timeout /t 5 >nul
exit /b 2

:run_editor
if not defined EDITOR goto :not_found
if not exist "%EDITOR%" goto :not_found

start "" "%EDITOR%"
exit /b 0
