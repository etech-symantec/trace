ProxySG Trace Safe Launcher v1
================================

Purpose
-------
This rebuild removes the behavior most likely to look suspicious to endpoint heuristic engines.

Old design:
  browser -> resident launcher -> localhost listener -> network download -> EXE execution

Safe design:
  browser -> proxysg-trace://run -> one-shot CMD launcher -> already downloaded Editor

Security / behavior
-------------------
- No custom Launcher EXE is required.
- No background or startup process.
- No localhost HTTP service or open listening port.
- No automatic EXE download.
- No automatic update.
- No hidden PowerShell.
- No administrator rights.
- Only HKCU\Software\Classes\proxysg-trace is registered.
- Launcher uses only built-in cmd.exe and start.
- If the Editor is not found, the official Trace web page is opened.

Install
-------
1. Extract this ZIP.
2. Run Install_ProxySG_Trace_Launcher.cmd.
3. On the website, click Trace Editor Run.
4. If the Editor has not been downloaded yet, download it from the website.
   The launcher searches LocalAppData, its own folder, Downloads, and Desktop.

Uninstall
---------
Run Uninstall_ProxySG_Trace_Launcher.cmd.

Important
---------
This design should reduce heuristic detections, but an endpoint product can still block
scripts or unsigned applications according to local policy. The Policy Trace Editor EXE
itself remains unsigned unless your organization signs it with an Authenticode certificate.
