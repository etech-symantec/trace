﻿@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title ProxySG Trace Launcher - Install / Repair

echo.
echo ============================================================
echo   ProxySG Trace Launcher - Install / Repair
echo ============================================================
echo.
echo This installer:
echo   - does NOT install a background service
echo   - does NOT open a localhost port
echo   - does NOT download or execute another EXE
echo   - registers only the proxysg-trace:// URL protocol
echo   - installs only for the current Windows user
echo.
echo Install path:
echo   %%LOCALAPPDATA%%\Etech\ProxySGTrace
echo.
pause

set "APPDIR=%LOCALAPPDATA%\Etech\ProxySGTrace"
set "SOURCE=%~dp0ProxySG_Trace_Launcher.cmd"
set "TARGET=%APPDIR%\ProxySG_Trace_Launcher.cmd"

if not exist "%SOURCE%" (
  echo [ERROR] ProxySG_Trace_Launcher.cmd was not found next to this installer.
  pause
  exit /b 1
)

if not exist "%APPDIR%" mkdir "%APPDIR%" >nul 2>&1
copy /y "%SOURCE%" "%TARGET%" >nul
if errorlevel 1 (
  echo [ERROR] Could not copy the launcher to:
  echo %TARGET%
  pause
  exit /b 1
)

rem Build a small .reg file transparently and import it into HKCU only.
set "REGFILE=%TEMP%\proxysg_trace_launcher_%RANDOM%.reg"
set "COMSPEC_ESC=%ComSpec:\=\\%"
set "TARGET_ESC=%TARGET:\=\\%"

> "%REGFILE%" echo Windows Registry Editor Version 5.00
>>"%REGFILE%" echo.
>>"%REGFILE%" echo [HKEY_CURRENT_USER\Software\Classes\proxysg-trace]
>>"%REGFILE%" echo @="URL:ProxySG Trace Launcher"
>>"%REGFILE%" echo "URL Protocol"=""
>>"%REGFILE%" echo.
>>"%REGFILE%" echo [HKEY_CURRENT_USER\Software\Classes\proxysg-trace\shell]
>>"%REGFILE%" echo.
>>"%REGFILE%" echo [HKEY_CURRENT_USER\Software\Classes\proxysg-trace\shell\open]
>>"%REGFILE%" echo.
>>"%REGFILE%" echo [HKEY_CURRENT_USER\Software\Classes\proxysg-trace\shell\open\command]
>>"%REGFILE%" echo @="\"%COMSPEC_ESC%\" /d /c \"\"%TARGET_ESC%\" \"%%1\"\""

reg import "%REGFILE%" >nul 2>&1
set "RC=%ERRORLEVEL%"
del /q "%REGFILE%" >nul 2>&1

if not "%RC%"=="0" (
  echo [ERROR] URL protocol registration failed.
  echo No administrator rights should be required because this uses HKCU.
  pause
  exit /b 1
)

echo.
echo [OK] Installation / repair completed.
echo.
echo Registered protocol:
echo   proxysg-trace://run
echo.
echo No background process is running.
echo You can close this window and use "Trace Editor Run" on the web page.
echo.
pause
exit /b 0
